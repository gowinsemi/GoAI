from lib2to3.tests import load_tests
import unittest

if __name__ == '__main__':
    unittest.main()
